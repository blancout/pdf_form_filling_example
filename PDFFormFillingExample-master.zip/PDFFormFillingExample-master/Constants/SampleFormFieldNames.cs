﻿using System;
namespace PDFFormFillingExample
{
    public struct SampleFormFieldNames
    {
        public const string FirstName = "First Name";
        public const string LastName = "Last Name";
        public const string IAmAwesomeCheck = "Awesome Checkbox";
    }
}
