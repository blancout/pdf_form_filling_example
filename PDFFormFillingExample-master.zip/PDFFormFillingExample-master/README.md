# PDFFormFillingExample
An ASP.NET core simple project that demonstrates using iTextSharp library for .NET core to read and fill out a PDF form. 

More details on my [blog](https://wp.me/p9wYwo-jA)
